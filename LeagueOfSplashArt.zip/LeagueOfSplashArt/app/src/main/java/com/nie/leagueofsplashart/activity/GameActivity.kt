package com.nie.leagueofsplashart.activity

import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.util.AttributeSet
import android.view.ContextThemeWrapper
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.airbnb.paris.Paris
import com.nie.leagueofsplashart.R
import com.nie.leagueofsplashart.enums.ChampionsFBEnum





class GameActivity : AppCompatActivity() {

    private var tentativa : String = ""
    private var resposta : String = "LULU"

    private var listLetterAnswer = ArrayList<Button>()

    private lateinit var answerLayout : LinearLayout;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        answerLayout = findViewById(R.id.answerLayout)

        for(i in 0 until answerLayout.childCount) {
            listLetterAnswer.add(answerLayout.getChildAt(i) as Button);


        }

//        Toast.makeText(this, listLetterAnswer.size, Toast.LENGTH_SHORT).show();

        escolheCampeao();

    }

    fun adicionarLetra(view: View){

        val letra = view.tag.toString()

        tentativa = tentativa.plus(letra)

        colocaLetraNoSlot(letra);

        if(resposta.length == tentativa.length) {
            Toast.makeText(this, "Errrrou!", Toast.LENGTH_SHORT).show();
            limpaCampos();
            return
        }
    }

    private fun colocaLetraNoSlot(letra: String) {
        listLetterAnswer.forEach {
            if (it.text.isNullOrEmpty()) {
                it.text = letra
                return
            }
        }
    }

    private fun limpaCampos() {
        listLetterAnswer.forEach {
            it.text = ""
        }

        tentativa = "";
    }

    private fun escolheCampeao() {
        val random = ChampionsFBEnum.getRandom()




        val button = Button(this);

        button.text = "Q"

        Paris.styleBuilder(button)
            .add(R.style.ChoiceButton)
            .apply();

        answerLayout.addView(button)

        val button2 = Button(this);

        button.text = "2"

        Paris.styleBuilder(button2)
            .add(R.style.ChoiseAfterSpace)
            .apply();

        answerLayout.addView(button2)


    }
}
