package com.nie.leagueofsplashart.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.nie.leagueofsplashart.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun jogar(view: View) {
        val intent = Intent(applicationContext, GameActivity::class.java)
        startActivity(intent)
    }
}
