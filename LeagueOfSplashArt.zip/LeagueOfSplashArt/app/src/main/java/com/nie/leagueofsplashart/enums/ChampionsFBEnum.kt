package com.nie.leagueofsplashart.enums

enum class ChampionsFBEnum(var nome: String, var opcoes: String, var imagem: String) {

    AATROX( "AATROX", "AATROXOPIUYTREW", "aatrox.png");


    companion object {
        fun getRandom(): ChampionsFBEnum {

            val random = (0 until ChampionsFBEnum.values().size).shuffled().first()

            return ChampionsFBEnum.values().get(random)

        }
    }
}